package myvarsityplugp.something.varsityplug;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;

public class StudentRegistration extends AppCompatActivity {


    private EditText name,degree,email,password;
    private Button registerButton;
    private FirebaseAuth firebaseAuth;
    private ImageView userProfilePic;
    private ProgressDialog progressDialog1;
    private FirebaseStorage firebaseStorage;
    private static int PICK_IMAGE = 123;
    Uri imagePath;
    private StorageReference storageReference;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        if (requestCode==PICK_IMAGE && resultCode==RESULT_OK && data.getData()!=null){
            imagePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),imagePath);
                userProfilePic.setImageBitmap(bitmap);

            }catch (IOException e){
                e.printStackTrace();
            }


        }
        super.onActivityResult(requestCode,resultCode,data);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_registration);

        name = (EditText)findViewById(R.id.name_tv);
        degree = (EditText)findViewById(R.id.degree_tv);
        email = (EditText)findViewById(R.id.email_et);
        password = (EditText)findViewById(R.id.register_password_et);
        userProfilePic = (ImageView)findViewById(R.id.profilePic_iv);
        registerButton = (Button)findViewById(R.id.register_btn);
        progressDialog1 = new ProgressDialog(this);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();

        storageReference = firebaseStorage.getReference();

        userProfilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Image"), PICK_IMAGE);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (validate()){

                    // upload to database
                    String Email1 = email.getText().toString().trim();
                    String pass1 = password.getText().toString().trim();

                    progressDialog1.setMessage("Registering...");
                    progressDialog1.show();
                    firebaseAuth.createUserWithEmailAndPassword(Email1,pass1).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                sendEmailVerification();
                            }else{
                                progressDialog1.dismiss();
                                Toast.makeText(StudentRegistration.this,"Registration failed! Check Internet Connection!",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });




                }
            }
        });




    }


    private Boolean validate(){
        Boolean truth = false;
        String Name = name.getText().toString();
        String Email = email.getText().toString();
        String pass = password.getText().toString();
        String Degree = degree.getText().toString();


        if (imagePath == null){
            Toast.makeText(StudentRegistration.this,"Click Image Icon And Select Profile Picture",Toast.LENGTH_SHORT).show();
        }else if (Name.isEmpty() || Email.isEmpty() || pass.isEmpty() || Degree.isEmpty() || imagePath==null){
            Toast.makeText(StudentRegistration.this,"Please enter all details!",Toast.LENGTH_SHORT).show();
        }else if(Email.length()!=21 || !Email.contains("@myuct.ac.za")){
            Toast.makeText(StudentRegistration.this,"Invalid UCT email!",Toast.LENGTH_SHORT).show();
        }
        else{
            truth = true;
        }
        return truth;
    }

    private void sendEmailVerification(){
        final FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();

        if (firebaseUser !=null){
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()){
                        progressDialog1.dismiss();
                        sendUserData();
                        Toast.makeText(StudentRegistration.this,"Registered!",Toast.LENGTH_SHORT).show();
                        firebaseAuth.signOut();
                        finish();
                        startActivity(new Intent(StudentRegistration.this,MainActivity.class));

                    }else{
                        Toast.makeText(StudentRegistration.this,"Check Internet Connection!",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }


    private void sendUserData(){
        String Name = name.getText().toString();
        String Email = email.getText().toString();
        String Degree = degree.getText().toString();


        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference("Students").child(Email.substring(0,9).toLowerCase());
        StorageReference imageReference = storageReference.child(Email.substring(0,9).toLowerCase()).child("images").child("Profile Pic"); //user Id/images/profile pic.png
        UploadTask uploadTask = imageReference.putFile(imagePath);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(StudentRegistration.this,"File Upload Failed!",Toast.LENGTH_SHORT).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(StudentRegistration.this,"File Upload Successful!",Toast.LENGTH_SHORT).show();
            }
        });
        UserProfile userProfile = new UserProfile(Name,Email,Degree);
        myRef.setValue(userProfile);

    }


}
