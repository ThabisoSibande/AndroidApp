package myvarsityplugp.something.varsityplug;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class TutorRegistration extends AppCompatActivity {

    private EditText name, available, charge, details, courses;
    private String email;
    private ProgressDialog progressDialog;
    private Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_registration);

        name = (EditText)findViewById(R.id.tutorName_et);
        available = (EditText)findViewById(R.id.apTime_et);
        charge = (EditText)findViewById(R.id.tutorRate_et);
        details = (EditText)findViewById(R.id.contactDetails_et);
        courses = (EditText)findViewById(R.id.coursesTutoring_et);
        Bundle mBundle = getIntent().getExtras();
        email = mBundle.getString("com.something.varsityplug.TUTOR_EMAIL1");
        progressDialog = new ProgressDialog(this);


        register = (Button)findViewById(R.id.tutorRegister_btn);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                DatabaseReference myRef = firebaseDatabase.getReference("Tutors").child(email.toLowerCase());
                if (myRef.toString().equals(email)){
                    Toast.makeText(TutorRegistration.this, "Already Registered!", Toast.LENGTH_SHORT).show();
                }
                else if (validate()){
                    progressDialog.setMessage("Registering..");
                    progressDialog.show();
                    sendUserData();
                }
            }
        });


    }

    private Boolean validate(){
        Boolean truth = false;
        String tutorName = name.getText().toString();
        String tutorAvailable = available.getText().toString();
        String tutorCharge = charge.getText().toString();
        String tutorDetails = details.getText().toString();
        String tutorCourses = courses.getText().toString();


        if (tutorName.isEmpty() || tutorAvailable.isEmpty() || tutorCharge.isEmpty() || tutorDetails.isEmpty() || tutorCourses.isEmpty()){
            Toast.makeText(TutorRegistration.this,"Please enter all details!",Toast.LENGTH_SHORT).show();
        }
        else{
            truth = true;
        }
        return truth;
    }

    private void sendUserData(){
        String tutorName = name.getText().toString();
        String tutorAvailable = available.getText().toString();
        String tutorCharge = "R"+charge.getText().toString();
        String tutorDetails = details.getText().toString();
        String tutorCourses = courses.getText().toString();


        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference myRef = firebaseDatabase.getReference("Tutors").child(email.toLowerCase());
        TutorProfile tutorProfile = new TutorProfile(tutorName,tutorAvailable,tutorCharge,tutorDetails,tutorCourses,email);
        myRef.setValue(tutorProfile);
        progressDialog.dismiss();
        Toast.makeText(TutorRegistration.this,"You are now a registered Freelance tutor!",Toast.LENGTH_SHORT).show();
        finish();

    }
}
