package myvarsityplugp.something.varsityplug;

public class TutorProfile {

    private String tutorName, tutorAvailability, tutorDetails, tutorCourses, tutorEmail;
    private String tutorCharge;
    private String tutorVerified;
    private String tutorRating;




    public TutorProfile(String tutorName, String tutorAvailability, String tutorCharge, String tutorDetails, String tutorCourses, String tutorEmail){
        this.tutorName = tutorName;
        this.tutorAvailability = tutorAvailability;
        this.tutorDetails = tutorDetails;
        this.tutorCourses = tutorCourses;
        this.tutorCharge = tutorCharge;
        this.tutorEmail = tutorEmail;
        this.tutorVerified = "false";
        this.tutorRating = "0";


    }



    public TutorProfile(){
    }

    public String getTutorAvailability() {
        return tutorAvailability;
    }

    public String getTutorName() {
        return tutorName;
    }

    public String getTutorCharge() {
        return tutorCharge;
    }

    public String getTutorCourses() {
        return tutorCourses;
    }

    public String getTutorDetails() {
        return tutorDetails;
    }

    public String getTutorEmail(){
        return tutorEmail;
    }

    public String getTutorVerified() {
        return tutorVerified;
    }

    public String getTutorRating(){return tutorRating;}

    public void setTutorAvailability(String tutorAvailability) {
        this.tutorAvailability = tutorAvailability;
    }

    public void setTutorEmail(String tutorEmail) {
        this.tutorEmail = tutorEmail;
    }

    public void setTutorRating(String num){
        this.tutorRating = num;
    }

    /**public void updateRating(Integer num){

    }*/

    public void setTutorCharge(String tutorCharge) {
        this.tutorCharge = tutorCharge;
    }

    public void setTutorCourses(String tutorCourses) {
        this.tutorCourses = tutorCourses;
    }

    public void setTutorDetails(String tutorDetails) {
        this.tutorDetails = tutorDetails;
    }

    public void setTutorName(String tutorName) {
        this.tutorName = tutorName;
    }
}
