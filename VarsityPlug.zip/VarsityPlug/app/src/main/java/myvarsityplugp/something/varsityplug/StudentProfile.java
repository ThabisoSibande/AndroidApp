package myvarsityplugp.something.varsityplug;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.Picasso;

public class StudentProfile extends AppCompatActivity {


    private ImageView profilePicture;
    private TextView profileName, profileEmail, profileDegree;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private ImageView profileSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);

        profilePicture = (ImageView)findViewById(R.id.ivProfilePicture);
        profileName = (TextView) findViewById(R.id.tvProfileName);
        profileEmail = (TextView)findViewById(R.id.tvProfileEmail);
        profileDegree = (TextView)findViewById(R.id.tvProfileDegree);
        profileSettings = (ImageView)findViewById(R.id.user_settings);


        profileSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StudentProfile.this,ProfileUpdate.class));
            }
        });

        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();


        Bundle mBundle = getIntent().getExtras();
        String email = mBundle.getString("com.something.varsityplug.STUDENT_EMAIL").substring(0,9).toLowerCase();

        DatabaseReference databaseReference = firebaseDatabase.getReference("Students").child(email);
        storageReference = firebaseStorage.getReference();
        storageReference.child(email).child("images/Profile Pic").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).fit().centerCrop().memoryPolicy(MemoryPolicy.NO_CACHE).into(profilePicture);
            }
        });

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                UserProfile userProfile = dataSnapshot.getValue(UserProfile.class);
                profileName.setText(userProfile.getUserName());
                profileDegree.setText(userProfile.getUserDegree());
                profileEmail.setText(userProfile.getUserEmail());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(StudentProfile.this,databaseError.getCode(),Toast.LENGTH_SHORT).show();

            }
        });







    }


}
