package myvarsityplugp.something.varsityplug;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;

import com.something.varsityplug.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TutorsList extends AppCompatActivity {

    private ListView tutorsList;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private ArrayList<TutorProfile> listOFTutors;
    private ArrayList<TutorProfile> listOFNames;
    private TutorProfile userTutorProfile;
    private TutorsItemAdapter tutorsItemAdapter;
    private ImageView verified;
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutors_list);

        userTutorProfile = new TutorProfile();
        verified = (ImageView)findViewById(R.id.verification_icon);
        searchView = findViewById(R.id.turors_search_view);
        tutorsList = (ListView)findViewById(R.id.lvtutorsData);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Tutors");


        listOFTutors = new ArrayList<>();
        listOFNames = new ArrayList<>();

        tutorsItemAdapter = new TutorsItemAdapter(this,listOFTutors,listOFNames);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot ds: dataSnapshot.getChildren()){

                    userTutorProfile = ds.getValue(TutorProfile.class);
                    listOFTutors.add(userTutorProfile);
                    listOFNames.add(userTutorProfile);

                }
                tutorsList.setAdapter(tutorsItemAdapter);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                tutorsItemAdapter.getFilter().filter(newText);
                return false;
            }
        });

        tutorsList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent goToTutorProfile = new Intent(TutorsList.this,TutorCredentials.class);
                goToTutorProfile.putExtra("com.something.varsityplug.STDNO",tutorsItemAdapter.getTutorsList().get(position).getTutorEmail());
                startActivity(goToTutorProfile);
            }
        });


    }
}
