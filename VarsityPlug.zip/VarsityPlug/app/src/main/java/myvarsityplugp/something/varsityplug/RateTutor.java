package myvarsityplugp.something.varsityplug;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RateTutor extends AppCompatActivity {

    private EditText tutorId, tutorRating;
    private Button submitRate;
    private String tutorStudentNo;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private String rating;
    private FirebaseDatabase firebaseDatabase;
    private TutorProfile userTutorProfile;
    private String id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_tutor);

        firebaseAuth = FirebaseAuth.getInstance();


        tutorId = (EditText)findViewById(R.id.etTutorRateId);
        tutorRating = (EditText)findViewById(R.id.etRating);
        submitRate = (Button)findViewById(R.id.btnSubmitRating);

        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        id = firebaseUser.getEmail().substring(0,9).toLowerCase();







        submitRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tutorStudentNo = tutorId.getText().toString();
                rating = tutorRating.getText().toString();

                if (tutorStudentNo.isEmpty() && rating.isEmpty()){
                    Toast.makeText(RateTutor.this,"Enter all details!",Toast.LENGTH_SHORT).show();
                }else if (Integer.parseInt(rating)>5 || Integer.parseInt(rating)<0){
                    Toast.makeText(RateTutor.this,"Invalid number!",Toast.LENGTH_SHORT).show();
                }else if (id.equals(tutorStudentNo)){
                    Toast.makeText(RateTutor.this,"You can't rate yourself!",Toast.LENGTH_SHORT).show();

                }
                else if (tutorStudentNo.isEmpty()){
                    Toast.makeText(RateTutor.this,"Enter Tutor's Student Number!",Toast.LENGTH_SHORT).show();
                }else{




                    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = firebaseDatabase.getReference("Tutors").child(tutorStudentNo.toLowerCase().trim());

                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            userTutorProfile = dataSnapshot.getValue(TutorProfile.class);
                            userTutorProfile.setTutorRating(rating);
                            //TutorProfile utorProfile = new TutorProfile(tutorName,tutorAvailable,tutorCharge,tutorDetails,tutorCourses,email);



                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(RateTutor.this,databaseError.getCode(),Toast.LENGTH_SHORT).show();

                        }
                    });

                    if (userTutorProfile != null){
                        myRef.setValue(userTutorProfile);
                        Toast.makeText(RateTutor.this,"Tutor Rated!",Toast.LENGTH_SHORT).show();
                        finish();

                    }else{
                        Toast.makeText(RateTutor.this,"Click Button again to confirm!",Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });



    }

}
