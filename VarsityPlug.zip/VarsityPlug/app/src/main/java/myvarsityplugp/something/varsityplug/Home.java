package myvarsityplugp.something.varsityplug;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Home extends AppCompatActivity {


    private ImageButton tutorRegistration, searchTutors, tutorAds;
    private String email;
    private String studentMail;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser firebaseUser;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private DatabaseReference userAccount;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        Bundle mBundle = getIntent().getExtras();
        email = mBundle.getString("com.something.varsityplug.TUTOR_EMAIL");
        studentMail = mBundle.getString("com.something.varsityplug.TUTOR_EMAIL");
        databaseReference = firebaseDatabase.getReference("Tutors").child(email);
        firebaseUser = firebaseAuth.getCurrentUser();
        userAccount = firebaseDatabase.getReference("Students").child(firebaseUser.getEmail().substring(0,9).toLowerCase());



        tutorAds = (ImageButton)findViewById(R.id.btnTutorOrganisations);
        tutorAds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToWebsite = new Intent(Intent.ACTION_VIEW);
                goToWebsite.setData(Uri.parse("https://myvarsityplug.com"));
                startActivity(goToWebsite);
            }
        });





        tutorRegistration = (ImageButton)findViewById(R.id.tutorRegPage);
        tutorRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,TutorRegistration.class);
                intent.putExtra("com.something.varsityplug.TUTOR_EMAIL1",email);
                startActivity(intent);
            }
        });

        searchTutors = (ImageButton)findViewById(R.id.tutorsList_icon);
        searchTutors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this,TutorsList.class);
                //intent.putExtra("com.something.varsityplug.TUTOR_EMAIL2",email);
                startActivity(intent);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return true;
    }



    private void Logout(){
        firebaseAuth.signOut();
        finish();
        startActivity(new Intent(Home.this,MainActivity.class));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){


        switch(item.getItemId()){
            case R.id.logoutMenu:
                Logout();
                break;

            case R.id.profileMenu:
                Intent intent = new Intent(Home.this,StudentProfile.class);
                intent.putExtra("com.something.varsityplug.STUDENT_EMAIL",studentMail);
                startActivity(intent);
                break;

            case R.id.cancelTutoring:

                databaseReference.removeValue();
                startActivity(new Intent(Home.this,TutorsList.class));
                Toast.makeText(Home.this,"You are no longer a listed tutor!",Toast.LENGTH_SHORT).show();

                break;

            case R.id.changePassword:
                startActivity(new Intent(Home.this,PasswordReset.class));
                break;


            case R.id.RateOption:
                startActivity(new Intent(Home.this,RateTutor.class));
                break;

            case R.id.delAccount:
                Toast.makeText(Home.this,"Email myvarsityplug@gmail.com",Toast.LENGTH_SHORT).show();

                break;









        }
        return super.onOptionsItemSelected(item);
    }


}
