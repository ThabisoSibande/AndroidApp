package myvarsityplugp.something.varsityplug;

public class UserProfile {


    private String userName, userDegree, userEmail;

    public UserProfile(String userName, String userEmail,String userDegree){
        this.userName = userName;
        this.userDegree = userDegree;
        this.userEmail = userEmail;
    }

    public UserProfile(String userName, String userDegree){
        this.userName = userName;
        this.userDegree = userDegree;
    }


    public UserProfile(){
    }


    public String getUserDegree() {
        return userDegree;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getUserName() {
        return userName;
    }


    public void setUserDegree(String userDegree) {
        this.userDegree = userDegree;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

}
