package myvarsityplugp.something.varsityplug;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.something.varsityplug.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TutorsItemAdapter extends BaseAdapter implements Filterable{

    private ArrayList<TutorProfile> listOFTutors;
    private ArrayList<TutorProfile> listOFNames;
    private LayoutInflater layoutInflater;
    private ArrayList<TutorProfile> filterList;

    private FirebaseStorage firebaseStorage;
    private StorageReference storageReference;
    private CustomFilter filter;


    public TutorsItemAdapter(Context c, ArrayList<TutorProfile> a, ArrayList<TutorProfile> b){
        this.listOFTutors = b;
        this.filterList = a;
        this.listOFNames = a;
        this.layoutInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }


    @Override
    public int getCount() {
        return listOFNames.size();
    }

    @Override
    public Object getItem(int position) {
        return listOFNames.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = layoutInflater.inflate(R.layout.tutors_info,null);
        TextView email = (TextView)v.findViewById(R.id.tvtutorsInfo);
        final ImageView image = (ImageView)v.findViewById(R.id.tutorImage);


        firebaseStorage = FirebaseStorage.getInstance();

        String name = listOFNames.get(position).getTutorName();
        String Email = listOFNames.get(position).getTutorEmail();

        email.setText(name);


         storageReference = firebaseStorage.getReference();
         storageReference.child(Email.substring(0,9)).child("images/Profile Pic").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
        @Override
        public void onSuccess(Uri uri) {
        Picasso.get().load(uri).fit().centerCrop().into(image);
        }
        });

        return v;
    }

    @Override
    public Filter getFilter() {
        if (filter == null){
            filter = new TutorsItemAdapter.CustomFilter();
        }
        return filter;
    }

    //INNER CLASS CUSTOM_FILTER

    class CustomFilter extends Filter{

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {

            FilterResults results = new FilterResults();
            if (constraint != null && constraint.length()>0){

                // CONSTRAINT TO UPPER
                constraint = constraint.toString().toUpperCase();

                ArrayList<TutorProfile> filters = new ArrayList<TutorProfile>();

                // get specific items
                for (int i=0;i<filterList.size();i++){
                    if (filterList.get(i).getTutorName().toUpperCase().contains(constraint)){
                        filters.add(new TutorProfile(filterList.get(i).getTutorName(),filterList.get(i).getTutorAvailability(),filterList.get(i).getTutorCharge(),filterList.get(i).getTutorDetails(),filterList.get(i).getTutorCourses(),filterList.get(i).getTutorEmail()));
                    }
                    else  if (filterList.get(i).getTutorCourses().toUpperCase().contains(constraint)) {
                        filters.add(new TutorProfile(filterList.get(i).getTutorName(),filterList.get(i).getTutorAvailability(),filterList.get(i).getTutorCharge(),filterList.get(i).getTutorDetails(),filterList.get(i).getTutorCourses(),filterList.get(i).getTutorEmail()));
                    }
                }

                results.count = filters.size();
                results.values = filters;


            }else{
                results.count = filterList.size();
                results.values = filterList;
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            listOFNames = (ArrayList<TutorProfile>) results.values;
            notifyDataSetChanged();

        }


    }

    public ArrayList<TutorProfile> getTutorsList(){
        ArrayList<TutorProfile> temp = new ArrayList<TutorProfile>();

        for(TutorProfile userTutorProfile: listOFNames){
            temp.add(userTutorProfile);
        }
        return  temp;
    }
}
