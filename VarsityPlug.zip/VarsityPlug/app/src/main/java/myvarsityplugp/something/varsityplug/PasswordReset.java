package myvarsityplugp.something.varsityplug;

import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class PasswordReset extends AppCompatActivity {

    private Button updatePasswordButton;
    private EditText newPassword;
    private FirebaseUser firebaseUser;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);

        updatePasswordButton = (Button)findViewById(R.id.btnUpdatePassword);
        newPassword = (EditText)findViewById(R.id.etNewPassword);
       ;


        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        progressDialog = new ProgressDialog(this);

        updatePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                progressDialog.setMessage("Updating Password");
                progressDialog.show();

                String passwordNew = newPassword.getText().toString().trim();
                if (passwordNew.isEmpty()){
                    progressDialog.dismiss();
                    Toast.makeText(PasswordReset.this,"Enter New Password!",Toast.LENGTH_SHORT).show();

                }else {
                    firebaseUser.updatePassword(passwordNew.trim()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                progressDialog.dismiss();
                                Toast.makeText(PasswordReset.this,"Password Succesfully Updated!",Toast.LENGTH_SHORT).show();
                                finish();

                            }else{
                                progressDialog.dismiss();
                                Toast.makeText(PasswordReset.this,"Password Update Failed!",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }


            }
        });






    }
}
