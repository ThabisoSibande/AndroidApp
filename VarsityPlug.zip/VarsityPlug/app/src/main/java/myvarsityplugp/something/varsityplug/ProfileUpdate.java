package myvarsityplugp.something.varsityplug;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.something.varsityplug.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import myvarsityplugp.something.varsityplug.Home;
import myvarsityplugp.something.varsityplug.UserProfile;

public class ProfileUpdate extends AppCompatActivity {

    private EditText userNameUpdate, userDegreeUpdate;
    private Button update;
    private ImageView profilePictureUpdate;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private FirebaseStorage firebaseStorage;
    private ProgressDialog progressDialog;
    private FirebaseUser firebaseUser;
    private static int PICK_IMAGE = 123;
    Uri imagePath;
    private StorageReference storageReference;
    private String name,  degree;
    private DatabaseReference databaseReference;
    private UserProfile userProfile;


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        if (requestCode==PICK_IMAGE && resultCode==RESULT_OK && data.getData()!=null){
            imagePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),imagePath);
                profilePictureUpdate.setImageBitmap(bitmap);

            }catch (IOException e){
                e.printStackTrace();
            }


        }
        super.onActivityResult(requestCode,resultCode,data);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_update);


        update = (Button)findViewById(R.id.btnUpdate);
        profilePictureUpdate = (ImageView)findViewById(R.id.ivUpdatePPic);


        //progressDialog = new ProgressDialog(this);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();




        Toast.makeText(this,"Wait For Your Profile Image To Appear!",Toast.LENGTH_SHORT).show();
        storageReference = firebaseStorage.getReference();
        storageReference.child(firebaseUser.getEmail().substring(0,9).toLowerCase()).child("images/Profile Pic").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).fit().centerCrop().into(profilePictureUpdate);
            }
        });


        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    if (imagePath!= null){
                        StorageReference imageReference = storageReference.child(firebaseUser.getEmail().substring(0,9).toLowerCase()).child("images").child("Profile Pic"); //user Id/images/profile pic.png
                        UploadTask uploadTask = imageReference.putFile(imagePath);
                        uploadTask.addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(ProfileUpdate.this,"File Upload Failed!",Toast.LENGTH_SHORT).show();
                            }
                        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                //progressDialog.dismiss();
                                Toast.makeText(ProfileUpdate.this,"File Upload Successful!",Toast.LENGTH_SHORT).show();
                            }
                        });
                    }

                    finish();
                    Intent goToHome = new Intent(ProfileUpdate.this, Home.class);
                    goToHome.putExtra("com.something.varsityplug.TUTOR_EMAIL",firebaseUser.getEmail().substring(0,9).toLowerCase().trim());
                    startActivity(goToHome);

            }
        });

        profilePictureUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,"Select Image"), PICK_IMAGE);
            }
        });




    }



}
